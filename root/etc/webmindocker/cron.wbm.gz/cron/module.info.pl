desc_pl=Harmonogram zadaĂą Cron
longdesc_pl=TwĂłrz, edytuj i usuwaj zadania Cron.
