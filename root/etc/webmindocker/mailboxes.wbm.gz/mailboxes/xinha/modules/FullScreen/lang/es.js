// I18N constants
// LANG: "es", ENCODING: UTF-8
// translated: Derick Leony <dleony@gmail.com>
{
  "Maximize/Minimize Editor": "Maximizar/Minimizar Editor"
};