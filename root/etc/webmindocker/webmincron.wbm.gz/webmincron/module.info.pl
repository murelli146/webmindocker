desc_pl=Zaplanowane Funkcje Webmina
longdesc_pl=Określ funkcje Webmina, które mają być uruchamiane według regularnego harmonogramu przez serwer Webmin
